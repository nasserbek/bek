 
Arduino 33 IoT and Arduino MKR1010 are no longer supported by `Blynk.Edgent`.

Blynk now offers **a better solution for Dual-MCU boards**. Please use [`Blynk.NCP`](https://github.com/blynkkk/BlynkNcpExample).
