exports.audioData = [
];

/** Example format
exports.audioData = [
  {
    title: 'Title',
    url: 'https://domain.com/test.mp3',
  },
  {
    title: 'Title 2',
    url: 'https://domain.com/test2.mp3',
  },
  {
    title: 'Title 3',
    url: 'https://domain.com/test3.mp3',
  }
];

**/
