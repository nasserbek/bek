package de.awilhelmer.alexaskill.mqtt.model;

/**
 * Created by WilhelmerA on 06.02.2017.
 */
public enum DeviceType {
   LED, TV, POWER;
}
